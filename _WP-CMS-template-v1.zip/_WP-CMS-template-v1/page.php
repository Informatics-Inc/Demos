<?php /* Template Name: Default */
get_header();
?>

<main id="content">
   
    <?php the_content(); ?>
   
</main>

<?php 
    get_footer();
?>
